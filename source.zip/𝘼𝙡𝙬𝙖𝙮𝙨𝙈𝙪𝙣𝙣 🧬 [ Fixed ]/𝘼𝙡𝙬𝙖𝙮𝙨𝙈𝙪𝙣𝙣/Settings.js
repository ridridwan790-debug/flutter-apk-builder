//================================//
// Main
//================================//
global.prefa = ['!','.',',','🐤','🗿']
global.owner = ['6285876670135']
global.cd = '3'; // 300 detik cooldown
global.linkOwner = "t.me/MunaOfficiall"
//================================//
// Panel
//================================//
global.egg = "15"
global.nestid = "5"
global.loc = "1"
global.domain = "_"
global.apikey = "_"
global.capikey = "_"
//================================//
// Panel V2
//================================//
global.domain2 = "_"
global.apikey2 = "_"
global.capikey2 = "_"
//================================//
// Global Mess
//================================//
global.menuMode = global.menuMode || {};
global.mess = {
 owner: '*Lu Bukan Owner Gw Bang Coba AddOwner Dulu.*',
 premium: '*Lu Bukan User Premium Coba AddPrem Dulu*',
 group: '*Ini Fitur Buat Di Dalam Grup Doang Ya Abnggg*'
}