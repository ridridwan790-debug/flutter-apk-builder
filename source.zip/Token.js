const officialTokenValue = "8680123246:AAFUOFX1xOGxFvJpZPstoEkl2RhRF-mM3Ng";
module.exports = {
    officialToken: officialTokenValue
};