module.exports = {
  tokens: "8680123246:AAFUOFX1xOGxFvJpZPstoEkl2RhRF-mM3Ng",  // Ubah Jadi Token Bot Mu !!!
  owner: "8859497242", // Ubah Jadi Id Mu !!!
  port: "2073", // Ubah Jadi Port Panel Mu !!!
  ipvps: "https://ditszxsilid.fansjkt48.web.id" // Ubah Jadi Ip Vps Mu !!!
};