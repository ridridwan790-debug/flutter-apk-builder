module.exports = {
  BOT_TOKEN:
  "8466895839:AAFQzInjz5ppJb4uD6QUMPzRGnEnWfpCdrQ",
};