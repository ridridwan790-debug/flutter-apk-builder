module.exports = {
  tokens: "8680123246:AAFUOFX1xOGxFvJpZPstoEkl2RhRF-mM3Ng",  // Masukin Bot token kamu
  owners: "8859497242", // Masukin ID Telegram kamu
  port: "6195", // Masukin Port panel kamu 
  ipvps: "http://dalangstore.my.id" // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )
};