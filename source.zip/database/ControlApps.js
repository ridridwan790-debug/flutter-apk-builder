module.exports = {
  tokens: "8680123246:AAFUOFX1xOGxFvJpZPstoEkl2RhRF-mM3Ng", 
  owner: "8859497242", 
  port: "4000", // Ini Wajib Jangan Diubah
  ipvps: "http://tzyngentotcrot.hostingercloud.my.id" // Jangan Diubah Nanti Eror!!
};